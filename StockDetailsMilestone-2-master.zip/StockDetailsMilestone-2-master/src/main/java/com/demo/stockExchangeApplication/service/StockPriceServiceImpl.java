package com.demo.stockExchangeApplication.service;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import com.demo.stockExchangeApplication.dao.StockPriceDao;
import com.demo.stockExchangeApplication.model.StockPrice;

@Service
public class StockPriceServiceImpl implements StockPriceService {
	
	@Autowired
	StockPriceDao stockpricedao;

	@Override
	public List<StockPrice> getStockList() {
		return stockpricedao.findAll();
	}

	
	@Override
	public List<StockPrice> findBycompanycode(int companycode) {
		return stockpricedao.findBycompanycode(companycode);
	}


	@Override
	public void insertStock(MultipartFile file) throws IOException {
		 HSSFWorkbook offices= new HSSFWorkbook(file.getInputStream());
         HSSFSheet worksheet = offices.getSheet("Offices");
         HSSFRow entry;
         Integer noOfEntries=1;
         //getLastRowNum and getPhysicalNumberOfRows showing false values sometimes.
         while(worksheet.getRow(noOfEntries)!=null){
             noOfEntries++;
         }
         System.out.println(noOfEntries.toString());
         for(int rowIndex=1;rowIndex<noOfEntries;rowIndex++){
             entry=worksheet.getRow(rowIndex);
             Integer externalId=((Double)entry.getCell(0).getNumericCellValue()).intValue();
             String name=entry.getCell(2).getStringCellValue();
             Date openingDate=entry.getCell(3).getDateCellValue();
//             Date date = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(openingDate);
             StockPrice office=new StockPrice();
             office.setCompanycode(externalId);
             office.setStockExchange(name);
             office.setDate(openingDate);
             stockpricedao.save(office);
         }
	}
}
