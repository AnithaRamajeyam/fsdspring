package com.demo.stockExchangeApplication.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.demo.stockExchangeApplication.model.StockPrice;

public interface StockPriceService {


	public List<StockPrice> getStockList();

	public void insertStock(MultipartFile file) throws IOException;

	public List<StockPrice> findBycompanycode(int companycode);

}
