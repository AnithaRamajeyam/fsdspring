package com.demo.stockExchangeApplication.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Ipodetail")
public class IPODetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ipodeatail_id;
	private int companycode;
	private int stockExchange;
	private double pricePerShare;
	private int totalShares;
	private String openDateTime;
	private String remarks;
	
	
	public int getIpodeatail_id() {
		return ipodeatail_id;
	}
	public void setIpodeatail_id(int ipodeatail_id) {
		this.ipodeatail_id = ipodeatail_id;
	}
	
	public int getCompanycode() {
		return companycode;
	}
	public void setCompanycode(int companycode) {
		this.companycode = companycode;
	}
	public int getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(int stockExchange) {
		this.stockExchange = stockExchange;
	}
	public double getPricePerShare() {
		return pricePerShare;
	}
	public void setPricePerShare(double pricePerShare) {
		this.pricePerShare = pricePerShare;
	}
	public int getTotalShares() {
		return totalShares;
	}
	public void setTotalShares(int totalShares) {
		this.totalShares = totalShares;
	}
	public String getOpenDateTime() {
		return  openDateTime;
	}
	public void setOpenDateTime(String openDateTime) {
		this.openDateTime = openDateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
