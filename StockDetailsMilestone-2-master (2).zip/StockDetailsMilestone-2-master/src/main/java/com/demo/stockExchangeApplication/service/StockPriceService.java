package com.demo.stockExchangeApplication.service;

import java.util.List;

import com.demo.stockExchangeApplication.model.StockPrice;

public interface StockPriceService {


	public List<StockPrice> getStockList();

	public void insertStock(StockPrice stock);

}
