package com.demo.stockExchangeApplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.stockExchangeApplication.model.StockPrice;

public interface StockPriceDao extends JpaRepository<StockPrice, Integer> {

}
