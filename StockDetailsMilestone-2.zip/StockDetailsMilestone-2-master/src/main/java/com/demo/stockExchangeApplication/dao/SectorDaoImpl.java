package com.demo.stockExchangeApplication.dao;

public class SectorDaoImpl implements SectorDao {

}
