//package com.demo.stockExchangeApplication.dao;
//
//public class StockPriceDaoImpl implements StockPriceDao {
//
//}
