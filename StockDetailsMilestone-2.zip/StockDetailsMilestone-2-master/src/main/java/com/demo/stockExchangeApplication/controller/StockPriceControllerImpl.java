package com.demo.stockExchangeApplication.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.stockExchangeApplication.model.Company;
import com.demo.stockExchangeApplication.model.StockExchange;
import com.demo.stockExchangeApplication.model.StockPrice;
import com.demo.stockExchangeApplication.service.CompanyService;
import com.demo.stockExchangeApplication.service.StockPriceService;
@Controller
public class StockPriceControllerImpl {
		@Autowired
		private StockPriceService stockService;
		
		
		@Autowired
		private CompanyService companyService;
		
//		@RequestMapping(path="/stockList")
//		public ModelAndView getCompanyList() throws Exception {
//			ModelAndView mv=new ModelAndView();
//			mv.setViewName("stockList");
//			mv.addObject("stockList",stockService.getStockList());
//			return mv;
//		}
		
		
		@RequestMapping(path="/insertStock",method = RequestMethod.GET)
		public String insert()
		{
			StockPrice stock=new StockPrice();
			stock.setCurrentPrice(3000);
			stock.setDate(new Date());
			stock.setStockId(5);
			System.out.println("dwfdd");
			Company company=new Company();
			company.setCompanyCode(24);
			company.setCompanyName("cts");
			company.setTurnOver(new BigDecimal(434.45d));
			company.setBoardOfDirectors("john");
			company.setBriefWriteup("aaaaann");
			company.setCeo("mark");
			company.setSectorId(1);
			company.setStockCode(236);
			stock.setCompany(company);
			
			StockExchange stockex=new StockExchange();
			stockex.setStockExchangeName("NSE");
			stockex.setBrief("wdjkb");
			stockex.setContactAddress("Mumbai");
			stockex.setRemarks("AAAa");
			stock.setStockExchange(stockex);
			
			try {
				stockService.insertStock(stock);
				List<StockPrice> stocks=stockService.getStockList();
				for(StockPrice stock1:stocks){
					System.out.println(stock1.getStockId());
					System.out.println(stock1.getCompany().getCompanyName());
					System.out.println(stock1.getStockExchange().getStockExchangeName());
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "insert";
		}
}
