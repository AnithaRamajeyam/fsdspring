package com.demo.stockExchangeApplication.service;

public class SectorServiceImpl implements SectorService {

}
