package com.demo.stockExchangeApplication.dao;

public interface SectorDao {

}
