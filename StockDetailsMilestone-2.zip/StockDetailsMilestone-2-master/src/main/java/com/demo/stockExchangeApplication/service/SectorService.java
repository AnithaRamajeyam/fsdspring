package com.demo.stockExchangeApplication.service;

public interface SectorService {

}
